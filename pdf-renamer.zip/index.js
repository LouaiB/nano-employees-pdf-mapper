const fs = require('fs');
const PDFParser = require("pdf2json");


// Get PDF File Paths
let pdfPaths;
try {
    console.log('getting PDF files from "put-pdf-files-here" folder');
    pdfPaths = fs.readdirSync('./put-pdf-files-here').filter(path => path.match(/.+\.pdf$/).length > 0);
    console.log(`${pdfPaths.length} PDF files found`);
}
catch(e) {
    console.error(`Error reading PDF files from "put-pdf-files-here" folder. Error: "${e.message}"`);
    process.exit(1);
}

// Parse the PDFs
pdfPaths.forEach(pdfPath => {
    const pdfFullPath = `./put-pdf-files-here/${pdfPath}`;

    const pdfParser = new PDFParser();

    // Error Parsing
    pdfParser.on("pdfParser_dataError", errData => console.error(`Error parsing "${pdfPath}". Error: "errData.parserError"`));

    // Successful Parse
    pdfParser.on("pdfParser_dataReady", pdfData => {

        // Get Texts
        const texts = pdfData.Pages[0].Texts.map(t => t.R[0].T);

        // Get Name
        let name = '';
        const name1Raw = texts[0];
        const name2Raw = texts[1];
        const name1 = name1Raw.replace(/%20/g, ' ').trim();
        const name2 = name2Raw.replace(/%20/g, ' ').trim();
        if(name2.match(/^[A-Z\s]+$/)) name = name1;
        else name = name1 + name2;
        console.log(`[${pdfPath}] extracted name: "${name}"`);

        // Get Date
        let date = '';
        const dateIndex = texts.findIndex((text, index) => (
            (index < texts.length - 2) &&
            text.match(/^[a-zA-Z]{3}$/) &&
            texts[index + 1] == '-' &&
            texts[index + 2].match(/^[0-9]{2}$/)
        ));
        if(dateIndex !== -1) date = texts[dateIndex] + texts[dateIndex + 1] + texts[dateIndex + 2];
        console.log(`[${pdfPath}] ${date ? `extracted date: "${date}"` : 'no date found'}`);

        // Copy PDF into results directory with new name
        const newPdfName = date ? `${name} Invoice ${date}` : `${name} Invoice`;
        const newPdfFullPath = `./results/${newPdfName}.pdf`;
        try {
            fs.copyFileSync(pdfFullPath, newPdfFullPath);
            console.log(`[${pdfPath}] PDF copied into "${newPdfFullPath}"`);
        }
        catch(e) {
            console.error(`[${pdfPath}] error copying PDF into new file "${newPdfFullPath}". Error: ${e.message}`);
        }
    });

    pdfParser.loadPDF(pdfFullPath);
});

process.stdin.once('data', () => process.exit());
